package com.example.weighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DataActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private WeightDatabaseHelper dbHelper;
    private EditText dateInput, weightInput;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        dbHelper = new WeightDatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerViewData);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dateInput = findViewById(R.id.editTextDate);
        weightInput = findViewById(R.id.editTextWeight);
        addButton = findViewById(R.id.buttonAdd);

        loadEntries(); // Load entries from DB

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date = dateInput.getText().toString().trim();
                String weight = weightInput.getText().toString().trim();

                if (date.isEmpty() || weight.isEmpty()) {
                    Toast.makeText(DataActivity.this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
                } else {
                    dbHelper.addEntry(date, weight);
                    dateInput.setText("");
                    weightInput.setText("");
                    loadEntries();
                    Toast.makeText(DataActivity.this, "Entry added", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadEntries() {
        List<WeightEntry> entries = dbHelper.getAllEntries();
        adapter = new WeightAdapter(entries);
        recyclerView.setAdapter(adapter);
    }
}
